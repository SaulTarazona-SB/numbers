package com.bolivar.comunes.numeros.demo.models;

public class ObtenernumeroenpalabrasResponse {

    private String response;

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

}
